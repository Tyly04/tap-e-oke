return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_down', 'holda' );
	Frames = Sprite.LinearFrames( 1, 1 );
};
