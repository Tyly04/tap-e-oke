return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_upright', 'holdi' );
	Frames = Sprite.LinearFrames( 1, 1 );
};
