return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_upright', 'holda' );
	Frames = Sprite.LinearFrames( 1, 1 );
};
