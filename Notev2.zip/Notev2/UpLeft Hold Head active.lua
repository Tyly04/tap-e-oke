return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_upleft', 'holda' );
	Frames = Sprite.LinearFrames( 1, 1 );
};
